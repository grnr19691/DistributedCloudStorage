javac SocketServer.java
java SocketServer 

javac *.java 
rmic FileImpl
rmic NodeServerImpl
java MainClass

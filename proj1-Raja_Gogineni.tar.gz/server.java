import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class threadsClass extends Thread 
{
	private Socket sock;
	static int count=0;
	int countFilesDownloaded=0;
	String workingDirectory;
	public threadsClass(Socket sock,String workingDirectory) 
	{
		this.sock = sock;
		this.workingDirectory=workingDirectory;
	}
	public void run() 
	{
		Lock mutex = new ReentrantLock(true);
		mutex.lock();
		count++;
		
		mutex.unlock();
		long startTime = System.currentTimeMillis();
		System.out.println("Going inside " + Thread.currentThread()+" with socket hash "+sock.hashCode()+"\n");
		System.out.println("The number of threads now are "+count);
		Scanner in=null;
		OutputStream out=null;
		PrintStream printWriter=null;
		try
		{
			in = new Scanner(sock.getInputStream());
			out = sock.getOutputStream();
			printWriter = new  PrintStream(out);;
			boolean http1point1 = false;
			do 
			{
				String requestLine = in.nextLine();
				String line;
				String cnnectionHeader = "";
				http1point1 = false;
				do 
				{
					line = in.nextLine();
					if(line ==null )
						break;
					if (line.trim().length() == 0) 
					{
						break;
					}
					if (line.startsWith("Connection:") )
					{
						cnnectionHeader = line.substring(11).trim();
					}
				}
				while (true);
				String [] split=requestLine.split("\\s+");
				int idx = split.length;
				if (idx <3) 
				{
					printWriter.println("HTTP/1.0 400 Bad Request");
					printWriter.println("Connection: close");
					printWriter.println("");
					printWriter.flush();
					continue;
				}
				String httpMethod =split[0];
				idx = split.length;
				if (idx < 3) 
				{
					printWriter.println("HTTP/1.0 400 Bad Request");
					printWriter.println("Connection: close");
					printWriter.println("");
					printWriter.flush();
					continue;
				}
				String httpType=split[2];
				if (!httpType.equals("HTTP/1.0") && !httpType.equals("HTTP/1.1")) 
				{
					printWriter.println("HTTP/1.0 505 HTTP Version Not Supported");
					printWriter.println("Connection: close");
					printWriter.println("");
					printWriter.flush();
					continue;
				}
				if (cnnectionHeader != "") 
				{
					http1point1 = cnnectionHeader.equalsIgnoreCase("keep-alive");
				}
				else if (httpType.equals("HTTP/1.1")) 
				{
					http1point1 = true;
				}
				else 
				{
					http1point1 = false;
				}				
				String filePath = split[1];
				if(filePath.equals("/"))
					filePath=filePath+"index.html";
				System.out.println(filePath);
				if (filePath.startsWith("/")) 
				{
					filePath = workingDirectory+filePath.substring(1);
				}
				File f = new File(filePath);
				if (!f.exists()) 
				{
					printWriter.println(httpType + " 404 Not Found");
					printWriter.println("Content-Length: 0");
					if (http1point1) 
					{
						printWriter.println("Connection: keep-alive");
					} 
					else 
					{
						printWriter.println("Connection: close");
					}
					printWriter.println("");
					printWriter.flush();
					continue;
				}
				if (!f.canRead()) 
				{
					printWriter.println(httpType + " 403 Forbidden");
					printWriter.println("Content-Length: 0");
					if (http1point1) 
					{
						printWriter.println("Connection: keep-alive");
					} 
					else 
					{
						printWriter.println("Connection: close");
					}
					printWriter.println("");
					printWriter.flush();
					continue;
				}
				if (!(httpMethod.equals("GET"))) 
				{
					printWriter.println(httpType +" 405 Method Not Allowed");
					printWriter.println("Allow: GET");
					if (http1point1) 
					{
						printWriter.println("Connection: keep-alive");
					} 
					else 
					{
						printWriter.println("Connection: close");
					}
					printWriter.println("");
					printWriter.flush();
					continue;
				}
				printWriter.println(httpType + " 200 OK");
				printWriter.println("Content-Type: text/html");
				printWriter.print("Content-Length: ");
				printWriter.println(f.length());
				if (http1point1) 
				{
					printWriter.println("Connection: keep-alive");
				} 
				else 
				{
					printWriter.println("Connection: close");
				}
				printWriter.println("");
				printWriter.flush();
				FileInputStream fileInputStream = new FileInputStream(f);
				PrintStream fileSender = printWriter;
				byte[] buffer = new byte[1024];
				int bufferLength;
				while ((bufferLength = fileInputStream.read(buffer)) > 0) 
				{
					fileSender.write(buffer, 0, bufferLength);
					fileSender.flush();
				}
				countFilesDownloaded++;
				if((System.currentTimeMillis() - startTime)>3000/(count*5))
				{
					http1point1=false;
					break;
					
				}	
			}
			while (http1point1);
			mutex.lock();
			
			count--;

			mutex.unlock();
			System.out.println("Coming out of thread " + Thread.currentThread()+" with socket hash "+sock.hashCode());
			System.out.println("The number of files downloaded in this thread is "+countFilesDownloaded);
			System.out.println("This thread is closed\n");
			sock.close();
		}
		catch(Exception e1)
		{
		//	e1.printStackTrace();
		}
		finally 
		{
			try 
			{
				if (in != null)
				in.close();
			} 
			catch (Exception ignore) 
			{
			}
			try 
			{
				if (out != null)
					out.close();
			} 
			catch (Exception e) 
			{
			//	e.printStackTrace();
			}
			try 
			{
				if(sock!=null)
					sock.close();

			} 
			catch (Exception e) 
			{
			//	e.printStackTrace();
			}
			try
			{
				if(printWriter!=null)
					printWriter.close();
			}
			catch(Exception e)
			{
				//ie.printStackTrace();
			}
		}
	}
}



public class server 
{
	public static void main(String[] args)
	{
	    Socket sock = null;
        int portNumber = Integer.parseInt(args[1]); // the server port
		try 
		{
			ServerSocket serverSocket = new ServerSocket(portNumber);
			System.out.println(args[0]);
			while (true) 
			{
				sock = serverSocket.accept();
				threadsClass t=new threadsClass(sock,args[0]);
				
				t.start();
			}
	    } 
		catch (Exception e) 
		{
		//	e.printStackTrace();
        }
	}
}
